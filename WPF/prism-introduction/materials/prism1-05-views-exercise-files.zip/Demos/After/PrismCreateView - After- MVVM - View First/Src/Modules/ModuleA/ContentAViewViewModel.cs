﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ModuleA
{
    public class ContentAViewViewModel : IContentAViewViewModel
    {
        public ContentAViewViewModel()
        {

        }
    }
}
