﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using PluralsightPrismDemo.Infrastructure;

namespace ModuleA
{
    public interface IContentAViewViewModel : IViewModel
    {
    }
}
