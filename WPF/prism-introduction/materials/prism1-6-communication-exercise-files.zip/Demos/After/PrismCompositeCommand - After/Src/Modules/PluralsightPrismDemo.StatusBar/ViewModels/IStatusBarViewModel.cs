﻿using System;
using PluralsightPrismDemo.Infrastructure;

namespace PluralsightPrismDemo.StatusBar
{
    public interface IStatusBarViewModel : IViewModel
    {
        
    }
}
