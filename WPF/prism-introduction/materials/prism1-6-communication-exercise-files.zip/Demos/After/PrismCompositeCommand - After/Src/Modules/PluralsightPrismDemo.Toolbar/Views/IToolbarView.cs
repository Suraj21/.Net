using System;
using PluralsightPrismDemo.Infrastructure;

namespace PluralsightPrismDemo.Toolbar
{
    public interface IToolbarView : IView
    {

    }
}
