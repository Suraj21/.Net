using System;
using PluralsightPrismDemo.Infrastructure;

namespace PluralsightPrismDemo.People
{
    public interface IPersonDetailsView : IView
    {
        
    }
}
