using System;
using PluralsightPrismDemo.Infrastructure;

namespace PluralsightPrismDemo.People
{
    public interface IPeopleView : IView
    {

    }
}
