using System;
using PluralsightPrismDemo.Infrastructure;

namespace PluralsightPrismDemo.People
{
    public interface IPersonViewModel : IViewModel
    {

    }
}
