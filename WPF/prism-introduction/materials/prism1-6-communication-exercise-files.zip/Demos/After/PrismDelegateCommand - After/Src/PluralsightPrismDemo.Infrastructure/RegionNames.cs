﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace PluralsightPrismDemo.Infrastructure
{
    public class RegionNames
    {
        public static string StatusBarRegion = "StatusBarRegion";
        public static string ContentRegion = "ContentRegion";
    }
}
